const TYPES = {
   CoachController: Symbol.for('CoachController'),
   SubjectController: Symbol.for('SubjectController'),
 };
 
 export { TYPES };