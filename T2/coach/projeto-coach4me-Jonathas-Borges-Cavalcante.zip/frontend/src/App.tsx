
import RouterProvider from './routes';

import '@assets/styles/global.css';

function App() {
  return (
    <RouterProvider />
  );
}

export default App;